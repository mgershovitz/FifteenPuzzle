from distutils.core import setup

setup(
    name='FifteenPuzzle',
    version='0.6',
    packages=['fifteenpuzzle',],
    entry_points={'console_scripts': [
        'run_ui = fifteenpuzzle.game_ui:main_func',
    ]},
)