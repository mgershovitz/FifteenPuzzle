from distutils.core import setup

setup(
    name='FifteenPuzzle',
    version='0.1',
    packages=['fifteenpuzzle',],
    long_description=open('README.txt').read(),
)