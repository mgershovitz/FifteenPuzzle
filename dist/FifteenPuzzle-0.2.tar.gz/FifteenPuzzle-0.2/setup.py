from distutils.core import setup

setup(
    name='FifteenPuzzle',
    version='0.2',
    packages=['fifteenpuzzle',],
)