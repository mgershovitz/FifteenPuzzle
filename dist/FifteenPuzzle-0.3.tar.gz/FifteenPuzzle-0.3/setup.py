from distutils.core import setup

setup(
    name='FifteenPuzzle',
    version='0.3',
    packages=['fifteenpuzzle',],
)