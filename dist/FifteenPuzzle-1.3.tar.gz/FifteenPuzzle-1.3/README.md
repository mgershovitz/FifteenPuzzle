# FifteenPuzzle
FifteenPuzzle

A Python implementation of the sliding game "15 Puzzle" - https://en.wikipedia.org/wiki/15_puzzle

To install the game ues pip - 
pip install git+https://github.com/mgershovitz/FifteenPuzzle

After installing you can run the game with the command fifteenpuzzle
